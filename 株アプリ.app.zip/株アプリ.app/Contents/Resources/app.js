const STORAGE_KEY = "kabu-watchlist";

const listEl = document.getElementById("list");
const emptyEl = document.getElementById("empty");
const form = document.getElementById("addForm");
const input = document.getElementById("symbolInput");
const refreshBtn = document.getElementById("refreshBtn");
const indexStripEl = document.getElementById("indexStrip");
const heatmapEl = document.getElementById("heatmapView");
const newsListEl = document.getElementById("newsList");

// 主要指数
const INDICES = [
  { symbol: "^IXIC", label: "NASDAQ" },
  { symbol: "^GSPC", label: "S&P 500" },
  { symbol: "^DJI",  label: "Dow Jones" },
  { symbol: "^N225", label: "日経225" },
];

// 取得済み価格のキャッシュ（セクター・ヒートマップで共有）
const quoteCache = new Map();

let heatmapBuilt = false;
let newsRegion = "US";
let newsLoaded = false;
const newsPage   = { US: 0, JP: 0 };
const newsSeen   = { US: new Set(), JP: new Set() };
let newsLoadingMore = false;
let usSectorsSorted = false;
let jpSectorsSorted = false;

let symbols = loadSymbols();

function loadSymbols() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveSymbols() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(symbols));
}

function addSymbol(raw) {
  const symbol = raw.trim().toUpperCase();
  if (!symbol) return;
  if (symbols.includes(symbol)) {
    flashCard(symbol);
    return;
  }
  symbols.push(symbol);
  saveSymbols();
  createCard(symbol);
  updateEmpty();
  fetchOne(symbol);
}

function removeSymbol(symbol) {
  symbols = symbols.filter((s) => s !== symbol);
  saveSymbols();
  const card = document.getElementById(cardId(symbol));
  if (card) card.remove();
  updateEmpty();
}

function updateEmpty() {
  emptyEl.style.display = symbols.length ? "none" : "block";
}

function cardId(symbol) {
  return "card-" + symbol.replace(/[^A-Z0-9]/g, "_");
}

function createCard(symbol) {
  const card = document.createElement("div");
  card.className = "card loading";
  card.id = cardId(symbol);
  card.innerHTML = `
    <button class="remove" title="削除">×</button>
    <div class="name">${symbol}</div>
    <div class="symbol">${symbol}</div>
    <div class="price">— 読み込み中</div>
    <div class="change flat">&nbsp;</div>
    <svg class="spark" viewBox="0 0 300 56" preserveAspectRatio="none"></svg>
  `;
  card.querySelector(".remove").addEventListener("click", (e) => {
    e.stopPropagation();
    removeSymbol(symbol);
  });
  card.addEventListener("click", () => openChart(symbol));
  listEl.appendChild(card);
  return card;
}

function renderAll() {
  updateEmpty();
  listEl.innerHTML = "";
  for (const symbol of symbols) createCard(symbol);
}

function flashCard(symbol) {
  const card = document.getElementById(cardId(symbol));
  if (!card) return;
  card.animate(
    [{ outline: "2px solid var(--accent)" }, { outline: "2px solid transparent" }],
    { duration: 800 }
  );
}

function fmtPrice(value, currency) {
  if (value == null) return "—";
  const symbolMap = { USD: "$", JPY: "¥", EUR: "€" };
  const prefix = symbolMap[currency] || "";
  const digits = currency === "JPY" ? 0 : 2;
  return prefix + value.toLocaleString("ja-JP", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

async function fetchOne(symbol) {
  const card = document.getElementById(cardId(symbol));
  if (!card) return;
  card.classList.add("loading");
  try {
    const res = await fetch(`/api/quote?symbol=${encodeURIComponent(symbol)}`);
    const data = await res.json();
    if (data.error) {
      renderError(card, data.error);
      return;
    }
    renderQuote(card, data);
  } catch (e) {
    renderError(card, "サーバーに接続できません（server.py は動いていますか？）");
  }
}

function renderError(card, message) {
  card.classList.remove("loading");
  card.querySelector(".price").textContent = "—";
  card.querySelector(".change").innerHTML = "&nbsp;";
  let err = card.querySelector(".err");
  if (!err) {
    err = document.createElement("div");
    err.className = "err";
    card.appendChild(err);
  }
  err.textContent = "⚠ " + message;
}

function renderQuote(card, data) {
  card.classList.remove("loading");
  const existingErr = card.querySelector(".err");
  if (existingErr) existingErr.remove();

  card.querySelector(".name").textContent = data.name || data.symbol;
  card.querySelector(".symbol").textContent = data.symbol;
  card.querySelector(".price").textContent = fmtPrice(data.price, data.currency);

  const changeEl = card.querySelector(".change");
  if (data.change == null) {
    changeEl.className = "change flat";
    changeEl.innerHTML = "&nbsp;";
  } else {
    const up = data.change >= 0;
    changeEl.className = "change " + (data.change === 0 ? "flat" : up ? "up" : "down");
    const arrow = up ? "▲" : "▼";
    const sign = up ? "+" : "";
    changeEl.textContent = `${arrow} ${sign}${data.change.toFixed(2)} (${sign}${data.changePct.toFixed(2)}%)`;
  }

  drawSpark(card.querySelector(".spark"), data.closes, data.change);
}

function drawSpark(svg, closes, change) {
  svg.innerHTML = "";
  if (!closes || closes.length < 2) return;
  const W = 300, H = 56, pad = 3;
  const min = Math.min(...closes);
  const max = Math.max(...closes);
  const span = max - min || 1;
  const stepX = (W - pad * 2) / (closes.length - 1);
  const points = closes.map((c, i) => {
    const x = pad + i * stepX;
    const y = pad + (H - pad * 2) * (1 - (c - min) / span);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const color = change == null || change >= 0 ? "var(--up)" : "var(--down)";

  const area = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
  area.setAttribute("points", `${pad},${H} ${points.join(" ")} ${W - pad},${H}`);
  area.setAttribute("fill", color);
  area.setAttribute("opacity", "0.12");
  svg.appendChild(area);

  const line = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
  line.setAttribute("points", points.join(" "));
  line.setAttribute("fill", "none");
  line.setAttribute("stroke", color);
  line.setAttribute("stroke-width", "2");
  line.setAttribute("stroke-linejoin", "round");
  line.setAttribute("stroke-linecap", "round");
  svg.appendChild(line);
}

function refreshAll() {
  refreshBtn.disabled = true;
  Promise.all(symbols.map(fetchOne)).finally(() => {
    refreshBtn.disabled = false;
  });
}

// 更新ボタン: 表示中の画面に合わせて最新価格を取り直す
function handleRefresh() {
  if (currentView === "sectors-us" || currentView === "sectors-jp") {
    refreshSectors();
  } else if (currentView === "heatmap") {
    reloadHeatmap();
  } else if (currentView === "news") {
    loadNews(newsRegion);
  } else {
    refreshAll();
  }
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  addSymbol(input.value);
  input.value = "";
  input.focus();
});

document.querySelectorAll(".chip").forEach((chip) => {
  chip.addEventListener("click", () => addSymbol(chip.dataset.symbol));
});

refreshBtn.addEventListener("click", handleRefresh);

/* ===== セクター（米国株）ビュー ===== */

const SECTORS = [
  // 上昇・下落注目: 全静的セクターから前日比で自動ソート
  { name: "上昇注目", icon: "📈", dynamic: "UP",   stocks: [] },
  { name: "下落注目", icon: "📉", dynamic: "DOWN", stocks: [] },
  { name: "テクノロジー", icon: "💻", stocks: [
    ["AAPL", "Apple"], ["MSFT", "Microsoft"], ["NVDA", "NVIDIA"],
    ["AVGO", "Broadcom"], ["ORCL", "Oracle"], ["CRM", "Salesforce"],
    ["AMD", "AMD"], ["ADBE", "Adobe"], ["NOW", "ServiceNow"],
    ["INTC", "Intel"], ["QCOM", "Qualcomm"], ["TXN", "Texas Instr."],
  ]},
  { name: "通信・メディア", icon: "📡", stocks: [
    ["GOOGL", "Alphabet"], ["META", "Meta"], ["NFLX", "Netflix"],
    ["DIS", "Disney"], ["T", "AT&T"], ["VZ", "Verizon"],
    ["TMUS", "T-Mobile"], ["SPOT", "Spotify"],
  ]},
  { name: "一般消費財", icon: "🛍️", stocks: [
    ["AMZN", "Amazon"], ["TSLA", "Tesla"], ["HD", "Home Depot"],
    ["MCD", "McDonald's"], ["NKE", "Nike"], ["SBUX", "Starbucks"],
    ["ABNB", "Airbnb"], ["UBER", "Uber"],
  ]},
  { name: "生活必需品", icon: "🛒", stocks: [
    ["PG", "P&G"], ["KO", "Coca-Cola"], ["PEP", "PepsiCo"],
    ["COST", "Costco"], ["WMT", "Walmart"],
  ]},
  { name: "ヘルスケア", icon: "🏥", stocks: [
    ["UNH", "UnitedHealth"], ["JNJ", "J&J"], ["LLY", "Eli Lilly"],
    ["PFE", "Pfizer"], ["ABBV", "AbbVie"], ["MRK", "Merck"],
  ]},
  { name: "金融", icon: "🏦", stocks: [
    ["JPM", "JPMorgan"], ["BAC", "Bank of America"], ["V", "Visa"],
    ["MA", "Mastercard"], ["GS", "Goldman Sachs"], ["WFC", "Wells Fargo"],
    ["COIN", "Coinbase"], ["HOOD", "Robinhood"], ["PYPL", "PayPal"],
  ]},
  { name: "エネルギー", icon: "🛢️", stocks: [
    ["XOM", "ExxonMobil"], ["CVX", "Chevron"], ["COP", "ConocoPhillips"],
    ["OXY", "Occidental"], ["SLB", "SLB"], ["MPC", "Marathon Petroleum"],
  ]},
  { name: "資本財", icon: "🏗️", stocks: [
    ["CAT", "Caterpillar"], ["BA", "Boeing"], ["GE", "GE Aerospace"],
    ["HON", "Honeywell"], ["UPS", "UPS"], ["FDX", "FedEx"], ["DE", "Deere"],
  ]},
  { name: "半導体", icon: "🔬", stocks: [
    ["NVDA", "NVIDIA"], ["AMD", "AMD"], ["AVGO", "Broadcom"],
    ["QCOM", "Qualcomm"], ["TXN", "Texas Instr."], ["INTC", "Intel"],
    ["MU", "Micron"], ["AMAT", "Applied Materials"], ["LRCX", "Lam Research"],
    ["KLAC", "KLA Corp"], ["ARM", "Arm Holdings"], ["ASML", "ASML"],
  ]},
  { name: "量子コンピューティング", icon: "⚛️", stocks: [
    ["IONQ", "IonQ"], ["RGTI", "Rigetti Computing"], ["QUBT", "Quantum Computing"],
    ["QBTS", "D-Wave Quantum"], ["IBM", "IBM"], ["GOOGL", "Alphabet"],
    ["MSFT", "Microsoft"], ["HON", "Honeywell"],
  ]},
  { name: "蓄電池・エネルギー貯蔵", icon: "🔋", stocks: [
    ["TSLA", "Tesla"], ["ENPH", "Enphase Energy"], ["QS", "QuantumScape"],
    ["SLDP", "Solid Power"], ["STEM", "Stem Inc"], ["FLNC", "Fluence Energy"],
    ["ALB", "Albemarle"], ["SQM", "SQM"], ["BE", "Bloom Energy"],
    ["PLUG", "Plug Power"], ["RIVN", "Rivian"], ["LCID", "Lucid"],
  ]},
  { name: "不動産・REIT", icon: "🏠", stocks: [
    ["SPG", "Simon Property"], ["AMT", "American Tower"], ["PLD", "Prologis"],
    ["EQIX", "Equinix"], ["O", "Realty Income"], ["PSA", "Public Storage"],
    ["DLR", "Digital Realty"], ["VICI", "VICI Properties"], ["AVB", "AvalonBay"],
  ]},
  { name: "AI・クラウドSaaS", icon: "🤖", stocks: [
    ["PLTR", "Palantir"], ["SNOW", "Snowflake"], ["NET", "Cloudflare"],
    ["DDOG", "Datadog"], ["MDB", "MongoDB"], ["AI", "C3.ai"],
    ["GTLB", "GitLab"], ["HUBS", "HubSpot"], ["BILL", "Bill.com"],
    ["ZI", "ZoomInfo"],
  ]},
  { name: "サイバーセキュリティ", icon: "🔐", stocks: [
    ["CRWD", "CrowdStrike"], ["PANW", "Palo Alto"], ["FTNT", "Fortinet"],
    ["ZS", "Zscaler"], ["OKTA", "Okta"], ["S", "SentinelOne"],
    ["CYBR", "CyberArk"], ["QLYS", "Qualys"],
  ]},
  { name: "航空宇宙・防衛", icon: "✈️", stocks: [
    ["LMT", "Lockheed Martin"], ["RTX", "RTX Corp"], ["NOC", "Northrop Grumman"],
    ["GD", "General Dynamics"], ["TDG", "TransDigm"], ["HEI", "HEICO"],
    ["LDOS", "Leidos"], ["BAH", "Booz Allen"],
  ]},
  { name: "バイオテック", icon: "🧬", stocks: [
    ["MRNA", "Moderna"], ["BNTX", "BioNTech"], ["GILD", "Gilead"],
    ["REGN", "Regeneron"], ["BIIB", "Biogen"], ["VRTX", "Vertex"],
    ["ILMN", "Illumina"], ["SRPT", "Sarepta"],
  ]},
  { name: "EV・モビリティ", icon: "🚘", stocks: [
    ["TSLA", "Tesla"], ["RIVN", "Rivian"], ["LCID", "Lucid"],
    ["F", "Ford"], ["GM", "General Motors"], ["NIO", "NIO"],
    ["XPEV", "XPeng"], ["LI", "Li Auto"],
  ]},
  { name: "クリーンエネルギー", icon: "🌱", stocks: [
    ["FSLR", "First Solar"], ["NEE", "NextEra Energy"], ["ENPH", "Enphase"],
    ["RUN", "Sunrun"], ["SEDG", "SolarEdge"], ["AES", "AES Corp"],
    ["BEP", "Brookfield Renew."], ["CWEN", "Clearway Energy"],
    ["ORA", "Ormat Tech"], ["BE", "Bloom Energy"],
  ]},
  { name: "eコマース", icon: "🛒", stocks: [
    ["AMZN", "Amazon"], ["SHOP", "Shopify"], ["ETSY", "Etsy"],
    ["EBAY", "eBay"], ["MELI", "MercadoLibre"], ["PDD", "PDD Holdings"],
    ["BABA", "Alibaba"], ["JD", "JD.com"], ["WISH", "ContextLogic"],
  ]},
  { name: "医療機器", icon: "🩺", stocks: [
    ["ISRG", "Intuitive Surgical"], ["MDT", "Medtronic"], ["SYK", "Stryker"],
    ["ZBH", "Zimmer Biomet"], ["BSX", "Boston Scientific"],
    ["EW", "Edwards Lifesciences"], ["BAX", "Baxter"], ["COO", "CooperSurgical"],
  ]},
  { name: "米国銀行", icon: "🏛️", stocks: [
    ["JPM", "JPMorgan Chase"], ["BAC", "Bank of America"], ["WFC", "Wells Fargo"],
    ["C", "Citigroup"], ["GS", "Goldman Sachs"], ["MS", "Morgan Stanley"],
    ["USB", "US Bancorp"], ["PNC", "PNC Financial"], ["TFC", "Truist"],
    ["CFG", "Citizens Financial"], ["KEY", "KeyCorp"], ["FITB", "Fifth Third"],
  ]},
  { name: "フィンテック", icon: "💳", stocks: [
    ["SQ", "Block"], ["AFRM", "Affirm"], ["UPST", "Upstart"],
    ["SOFI", "SoFi"], ["HOOD", "Robinhood"], ["COIN", "Coinbase"],
    ["PYPL", "PayPal"], ["AAPL", "Apple Pay/Wallet"],
  ]},
];

// SBI証券などで使われる東証の業種分類に基づく日本株セクター
const JP_SECTORS = [
  // 上昇・下落注目: 全静的JPセクターから前日比で自動ソート
  { name: "上昇注目", icon: "📈", dynamic: "JP_UP",   stocks: [] },
  { name: "下落注目", icon: "📉", dynamic: "JP_DOWN", stocks: [] },
  { name: "自動車・輸送機器", icon: "🚗", stocks: [
    ["7203.T", "トヨタ自動車"], ["7267.T", "ホンダ"], ["7201.T", "日産自動車"],
    ["7269.T", "スズキ"], ["7270.T", "SUBARU"], ["6902.T", "デンソー"],
  ]},
  { name: "電気機器", icon: "🔌", stocks: [
    ["6758.T", "ソニーG"], ["6861.T", "キーエンス"], ["6501.T", "日立製作所"],
    ["6981.T", "村田製作所"], ["6752.T", "パナソニックHD"], ["6594.T", "ニデック"],
  ]},
  { name: "情報・通信", icon: "📡", stocks: [
    ["9984.T", "ソフトバンクG"], ["9432.T", "NTT"], ["9433.T", "KDDI"],
    ["9434.T", "ソフトバンク"], ["4689.T", "LINEヤフー"], ["4751.T", "サイバーエージェント"],
  ]},
  { name: "銀行", icon: "🏦", stocks: [
    ["8306.T", "三菱UFJ"], ["8316.T", "三井住友FG"], ["8411.T", "みずほFG"],
    ["8308.T", "りそなHD"],
  ]},
  { name: "卸売・商社", icon: "🌐", stocks: [
    ["8058.T", "三菱商事"], ["8031.T", "三井物産"], ["8001.T", "伊藤忠商事"],
    ["8053.T", "住友商事"], ["8002.T", "丸紅"],
  ]},
  { name: "医薬品", icon: "💊", stocks: [
    ["4502.T", "武田薬品"], ["4503.T", "アステラス製薬"], ["4568.T", "第一三共"],
    ["4519.T", "中外製薬"],
  ]},
  { name: "小売", icon: "🛍️", stocks: [
    ["9983.T", "ファーストリテイリング"], ["3382.T", "セブン&アイ"], ["8267.T", "イオン"],
    ["9843.T", "ニトリHD"],
  ]},
  { name: "機械", icon: "⚙️", stocks: [
    ["6301.T", "コマツ"], ["6367.T", "ダイキン工業"], ["6954.T", "ファナック"],
    ["6273.T", "SMC"],
  ]},
  { name: "食料品", icon: "🍱", stocks: [
    ["2914.T", "JT"], ["2502.T", "アサヒGHD"], ["2503.T", "キリンHD"],
    ["2802.T", "味の素"],
  ]},
  { name: "化学・素材", icon: "🧪", stocks: [
    ["4063.T", "信越化学"], ["4452.T", "花王"], ["3407.T", "旭化成"],
    ["5401.T", "日本製鉄"],
  ]},
  { name: "保険・その他金融", icon: "💰", stocks: [
    ["8766.T", "東京海上HD"], ["8591.T", "オリックス"], ["8604.T", "野村HD"],
  ]},
  { name: "ゲーム・エンタメ", icon: "🎮", stocks: [
    ["7974.T", "任天堂"], ["9697.T", "カプコン"], ["7832.T", "バンナムHD"],
    ["9684.T", "スクエニHD"],
  ]},
  { name: "半導体", icon: "🔬", stocks: [
    ["8035.T", "東京エレクトロン"], ["6920.T", "レーザーテック"], ["6857.T", "アドバンテスト"],
    ["6146.T", "ディスコ"], ["7735.T", "SCREENホールディングス"], ["4063.T", "信越化学"],
    ["3436.T", "SUMCO"], ["6963.T", "ローム"], ["6526.T", "ソシオネクスト"],
    ["6723.T", "ルネサスエレクトロニクス"], ["4062.T", "イビデン"], ["6981.T", "村田製作所"],
  ]},
  { name: "不動産", icon: "🏠", stocks: [
    ["8801.T", "三井不動産"], ["8830.T", "住友不動産"], ["8802.T", "三菱地所"],
    ["1925.T", "大和ハウス工業"], ["1928.T", "積水ハウス"], ["3003.T", "ヒューリック"],
  ]},
  { name: "航空・海運", icon: "✈️", stocks: [
    ["9201.T", "JAL"], ["9202.T", "ANAHD"], ["9101.T", "日本郵船"],
    ["9104.T", "商船三井"], ["9107.T", "川崎汽船"],
  ]},
  { name: "電力・ガス", icon: "💡", stocks: [
    ["9501.T", "東京電力HD"], ["9502.T", "中部電力"], ["9503.T", "関西電力"],
    ["9531.T", "東京ガス"], ["9532.T", "大阪ガス"],
  ]},
  { name: "建設", icon: "🏗️", stocks: [
    ["1801.T", "大成建設"], ["1802.T", "大林組"], ["1803.T", "清水建設"],
    ["1808.T", "長谷工"], ["1812.T", "鹿島建設"],
  ]},
  { name: "ITサービス", icon: "🖥️", stocks: [
    ["4307.T", "野村総研"], ["9613.T", "NTTデータG"], ["4704.T", "トレンドマイクロ"],
    ["2432.T", "DeNA"], ["3659.T", "ネクソン"],
  ]},
  { name: "鉄道・交通", icon: "🚂", stocks: [
    ["9020.T", "JR東日本"], ["9022.T", "JR東海"], ["9021.T", "JR西日本"],
    ["9005.T", "東急"], ["9007.T", "小田急電鉄"], ["9048.T", "名鉄"],
  ]},
  { name: "精密機器", icon: "🔭", stocks: [
    ["7741.T", "HOYA"], ["4543.T", "テルモ"], ["7731.T", "ニコン"],
    ["6506.T", "安川電機"], ["6315.T", "TOWA"], ["7762.T", "シチズン時計"],
  ]},
  { name: "鉄鋼・非鉄金属", icon: "⚙️", stocks: [
    ["5401.T", "日本製鉄"], ["5411.T", "JFE HD"], ["5713.T", "住友金属鉱山"],
    ["5706.T", "三菱マテリアル"], ["5108.T", "ブリヂストン"],
  ]},
  { name: "クリーンエネルギー", icon: "🌱", stocks: [
    ["6988.T", "日東電工"], ["6674.T", "GSユアサ"], ["7735.T", "SCREEN HD"],
    ["5334.T", "日本特殊陶業"], ["6981.T", "村田製作所"], ["4901.T", "富士フイルム"],
  ]},
];

const usSectorListEl = document.getElementById("sectorList");
const jpSectorListEl = document.getElementById("sectorListJp");

// 銘柄コード → 業種名 の対応表（注目セクターのタグ付けに使う）
const SECTOR_TAG = {};
[...SECTORS, ...JP_SECTORS].forEach((s) => {
  if (s.dynamic) return;
  (s.stocks || []).forEach((row) => {
    const sym = row[0];
    if (sym && !SECTOR_TAG[sym]) SECTOR_TAG[sym] = s.name;
  });
});

function tagFor(symbol) {
  if (symbol.endsWith("-USD")) return "暗号資産";
  return SECTOR_TAG[symbol] || "";
}

function typeLabel(t) {
  return { CRYPTOCURRENCY: "暗号資産", ETF: "ETF", INDEX: "指数", CURRENCY: "為替", FUTURE: "先物" }[t] || "";
}

function buildSectorGroup(sectors, container) {
  const loaded = new Set();
  sectors.forEach((sector, i) => {
    const block = document.createElement("div");
    block.className = "sector";
    const countText = sector.dynamic ? "自動集計TOP12" : `${sector.stocks.length}銘柄`;
    const dynAttr = sector.dynamic ? ` data-dynamic-type="${sector.dynamic}"` : "";
    block.dataset.sectorName = sector.name;
    block.innerHTML = `
      <button class="sector-head" aria-expanded="false">
        <span class="sector-title">${sector.icon} ${sector.name}</span>
        <span class="sector-count" data-base="${countText}">${countText}</span>
        <span class="sector-arrow">▾</span>
      </button>
      <div class="sector-body"${dynAttr} hidden></div>
    `;
    const head = block.querySelector(".sector-head");
    const body = block.querySelector(".sector-body");
    head.addEventListener("click", () => toggleSector(sector, head, body, loaded, i));
    container.appendChild(block);
  });
}

function toggleSector(sector, head, body, loaded, index) {
  const open = body.hasAttribute("hidden");
  if (open) {
    body.removeAttribute("hidden");
    head.setAttribute("aria-expanded", "true");
    head.classList.add("open");
    if (!loaded.has(index)) {
      loaded.add(index);
      if (sector.dynamic) {
        loadTrendingQuotes(body, sector.dynamic);
      } else {
        loadSectorQuotes(sector, body);
      }
    }
  } else {
    body.setAttribute("hidden", "");
    head.setAttribute("aria-expanded", "false");
    head.classList.remove("open");
  }
}

function makeSectorRow(symbol, name, tag, dynamic) {
  const row = document.createElement("div");
  row.className = "srow loading";
  row.dataset.symbol = symbol;
  if (dynamic) row.dataset.dynamic = "1";
  const tagHtml = tag ? `<span class="srow-tag">${tag}</span>` : "";
  row.innerHTML = `
    <button class="star" title="ウォッチリストに追加">☆</button>
    <span class="srow-symbol">${symbol}</span>
    <span class="srow-name"><span class="nm">${name || symbol}</span>${tagHtml}</span>
    <span class="srow-price">…</span>
    <span class="srow-change">&nbsp;</span>
  `;
  row.querySelector(".star").addEventListener("click", (e) => {
    e.stopPropagation();
    addSymbol(symbol);
    switchView("watchlist");
  });
  row.addEventListener("click", () => openChart(symbol));
  return row;
}

function loadSectorQuotes(sector, body) {
  body.innerHTML = "";
  for (const [symbol, name, tag] of sector.stocks) {
    const row = makeSectorRow(symbol, name, tag, false);
    body.appendChild(row);
    fetchSectorRow(row, symbol);
  }
}

// dynamicType: "UP"|"DOWN" (US) または "JP_UP"|"JP_DOWN" (JP)
async function loadTrendingQuotes(body, dynamicType) {
  const isJP   = dynamicType && dynamicType.startsWith("JP");
  const isDown = dynamicType && dynamicType.endsWith("DOWN");
  const label  = isDown ? "下落" : "上昇";
  body.innerHTML = `<div class="trend-note">全セクターから${label}銘柄を集計中…</div>`;

  const sourceList = isJP ? JP_SECTORS : SECTORS;
  const allStocks = [...new Map(
    sourceList
      .filter((s) => !s.dynamic)
      .flatMap((s) => s.stocks.map(([sym, name]) => ({ sym, name, sectorName: s.name })))
      .map((item) => [item.sym, item])
  ).values()];

  const results = await Promise.all(
    allStocks.map(async (item) => ({ ...item, data: await fetchAndCache(item.sym) }))
  );

  const filtered = results.filter((r) => r.data && r.data.changePct != null);
  const top = filtered
    .sort((a, b) => isDown
      ? a.data.changePct - b.data.changePct
      : b.data.changePct - a.data.changePct)
    .slice(0, 12);

  body.innerHTML = "";
  if (!top.length) {
    body.innerHTML = `<div class="trend-note">データを取得できませんでした。更新ボタンでもう一度お試しください。</div>`;
    return;
  }

  for (const { sym, name, sectorName } of top) {
    const row = makeSectorRow(sym, name, sectorName, false);
    body.appendChild(row);
    fetchSectorRow(row, sym);
  }
}

const quoteFetching = new Map(); // 同一銘柄の並列リクエストを1本に集約

async function fetchAndCache(symbol) {
  if (quoteCache.has(symbol)) return quoteCache.get(symbol);
  if (quoteFetching.has(symbol)) return quoteFetching.get(symbol);
  const p = (async () => {
    try {
      const res = await fetch(`/api/quote?symbol=${encodeURIComponent(symbol)}`);
      const d = await res.json();
      if (!d.error) quoteCache.set(symbol, d);
      return d.error ? null : d;
    } catch { return null; }
    finally { quoteFetching.delete(symbol); }
  })();
  quoteFetching.set(symbol, p);
  return p;
}

async function sortSectorsByPerformance(container, sectors) {
  const staticSectors = sectors.filter((s) => !s.dynamic);
  const sectorData = await Promise.all(
    staticSectors.map(async (sector) => {
      const results = await Promise.all(sector.stocks.map(([sym]) => fetchAndCache(sym)));
      const valid = results.filter((d) => d && d.changePct != null);
      const avg = valid.length
        ? valid.reduce((sum, d) => sum + d.changePct, 0) / valid.length
        : null;
      return { name: sector.name, count: sector.stocks.length, avg };
    })
  );
  sectorData.sort((a, b) => (b.avg ?? -Infinity) - (a.avg ?? -Infinity));
  for (const { name, count, avg } of sectorData) {
    const block = container.querySelector(`.sector[data-sector-name="${CSS.escape(name)}"]`);
    if (!block) continue;
    container.appendChild(block);
    const countEl = block.querySelector(".sector-count");
    if (countEl && avg != null) {
      const sign = avg >= 0 ? "+" : "";
      const arrow = avg >= 0 ? "▲" : "▼";
      const cls = avg > 0 ? "up" : "down";
      countEl.innerHTML = `${count}銘柄 <span class="sector-avg ${cls}">${arrow} ${sign}${avg.toFixed(2)}%</span>`;
    }
  }
}

async function fetchSectorRow(row, symbol) {
  try {
    const data = await fetchAndCache(symbol);
    row.classList.remove("loading");
    if (!data) {
      row.querySelector(".srow-price").textContent = "—";
      return;
    }
    // 注目セクターの行は、銘柄名と（タグが無ければ）種別タグを取得後に埋める
    if (row.dataset.dynamic === "1") {
      const nm = row.querySelector(".nm");
      if (nm) nm.textContent = data.name || symbol;
      if (!row.querySelector(".srow-tag")) {
        const label = typeLabel(data.type);
        if (label) {
          const span = document.createElement("span");
          span.className = "srow-tag";
          span.textContent = label;
          row.querySelector(".srow-name").appendChild(span);
        }
      }
    }
    row.querySelector(".srow-price").textContent = fmtPrice(data.price, data.currency);
    const changeEl = row.querySelector(".srow-change");
    if (data.change == null) {
      changeEl.innerHTML = "&nbsp;";
    } else {
      const up = data.change >= 0;
      changeEl.className = "srow-change " + (data.change === 0 ? "flat" : up ? "up" : "down");
      changeEl.textContent = `${up ? "▲" : "▼"} ${up ? "+" : ""}${data.changePct.toFixed(2)}%`;
    }
  } catch {
    row.classList.remove("loading");
    row.querySelector(".srow-price").textContent = "—";
  }
}

// 開いているセクターの現在価格を取り直す（表示中の画面のみ）
function refreshSectors() {
  const container = currentView === "sectors-jp" ? jpSectorListEl : usSectorListEl;
  const openBodies = container.querySelectorAll(".sector-body:not([hidden])");
  if (!openBodies.length) return;
  refreshBtn.disabled = true;
  const jobs = [];
  openBodies.forEach((body) => {
    if (body.dataset.dynamicType) {
      jobs.push(loadTrendingQuotes(body, body.dataset.dynamicType));
    } else {
      body.querySelectorAll(".srow").forEach((row) => {
        row.classList.add("loading");
        const priceEl = row.querySelector(".srow-price");
        if (priceEl) priceEl.textContent = "…";
        jobs.push(fetchSectorRow(row, row.dataset.symbol));
      });
    }
  });
  Promise.all(jobs).finally(() => {
    refreshBtn.disabled = false;
  });
}

/* ===== 主要指数ストリップ ===== */

async function refreshIndexStrip() {
  const results = await Promise.all(
    INDICES.map(({ symbol }) => fetchAndCache(symbol))
  );
  indexStripEl.innerHTML = "";
  results.forEach((data, i) => {
    const { label } = INDICES[i];
    const tile = document.createElement("div");
    tile.className = "idx-tile";
    if (!data) {
      tile.innerHTML = `<span class="idx-label">${label}</span><span class="idx-price">—</span>`;
    } else {
      const up = (data.change ?? 0) >= 0;
      const cls = data.change == null ? "flat" : up ? "up" : "down";
      const sign = up ? "+" : "";
      const chg = data.changePct != null
        ? `${up ? "▲" : "▼"} ${sign}${data.changePct.toFixed(2)}%`
        : "—";
      tile.innerHTML = `
        <span class="idx-label">${label}</span>
        <span class="idx-price">${fmtPrice(data.price, data.currency)}</span>
        <span class="idx-change ${cls}">${chg}</span>`;
    }
    indexStripEl.appendChild(tile);
  });
}

/* ===== セクターヒートマップ ===== */

function changeToColor(pct) {
  if (pct == null) return "var(--panel-2)";
  const t = Math.min(1, Math.abs(pct) / 5);
  const sat = Math.round(25 + 55 * t);
  const lit = Math.round(13 + 14 * t);
  return pct >= 0 ? `hsl(142,${sat}%,${lit}%)` : `hsl(0,${sat}%,${lit}%)`;
}

function buildHeatmap() {
  heatmapEl.innerHTML = "";
  const staticSectors = SECTORS.filter((s) => !s.dynamic);
  staticSectors.forEach((sector) => {
    const group = document.createElement("div");
    group.className = "hm-group";

    const head = document.createElement("div");
    head.className = "hm-head";
    head.dataset.icon = sector.icon;
    head.dataset.name = sector.name;
    head.textContent = `${sector.icon} ${sector.name}`;
    group.appendChild(head);

    const grid = document.createElement("div");
    grid.className = "hm-grid";

    sector.stocks.forEach(([symbol, name]) => {
      const tile = document.createElement("div");
      tile.className = "hm-tile loading";
      tile.dataset.symbol = symbol;
      tile.innerHTML = `<span class="hm-sym">${symbol}</span><span class="hm-pct">…</span><span class="hm-tag">${sector.name}</span><span class="hm-name">${name}</span>`;
      tile.addEventListener("click", () => openChart(symbol));
      grid.appendChild(tile);

      const cached = quoteCache.get(symbol);
      if (cached) {
        renderHmTile(tile, cached);
        updateHmHead(head, grid);
      } else {
        fetchAndCache(symbol).then((data) => {
          if (data) {
            renderHmTile(tile, data);
            updateHmHead(head, grid);
          } else {
            tile.classList.remove("loading");
            tile.querySelector(".hm-pct").textContent = "—";
          }
        });
      }
    });

    group.appendChild(grid);
    heatmapEl.appendChild(group);
  });
  heatmapBuilt = true;
}

function renderHmTile(tile, data) {
  tile.classList.remove("loading");
  tile.style.background = changeToColor(data.changePct);
  tile.dataset.pct = data.changePct ?? "";
  const pctEl = tile.querySelector(".hm-pct");
  if (data.changePct != null) {
    const sign = data.changePct >= 0 ? "+" : "";
    pctEl.textContent = `${sign}${data.changePct.toFixed(2)}%`;
    pctEl.className = "hm-pct " + (data.changePct > 0 ? "up" : data.changePct < 0 ? "down" : "flat");
  } else {
    pctEl.textContent = "—";
    pctEl.className = "hm-pct flat";
  }
}

function updateHmHead(head, grid) {
  const vals = [...grid.querySelectorAll(".hm-tile[data-pct]")]
    .map((t) => parseFloat(t.dataset.pct))
    .filter((v) => !isNaN(v));
  const total = grid.querySelectorAll(".hm-tile").length;
  if (!vals.length) return;
  const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
  const sign = avg >= 0 ? "+" : "";
  const cls = avg > 0 ? "up" : avg < 0 ? "down" : "flat";
  head.style.borderLeft = `4px solid ${avg >= 0 ? "var(--up)" : "var(--down)"}`;
  head.innerHTML =
    `${head.dataset.icon} ${head.dataset.name} ` +
    `<span class="hm-avg ${cls}">${sign}${avg.toFixed(2)}%</span> ` +
    `<span class="hm-count">${vals.length}/${total}</span>`;
}

function reloadHeatmap() {
  quoteCache.clear();
  heatmapBuilt = false;
  buildHeatmap();
}

/* ===== チャートモーダル（銘柄クリックで表示） ===== */

const modalEl = document.getElementById("chartModal");
const modalNameEl = modalEl.querySelector(".modal-name");
const modalSymbolEl = modalEl.querySelector(".modal-symbol");
const modalPriceEl = modalEl.querySelector(".modal-price");
const modalChangeEl = modalEl.querySelector(".modal-change");
const modalChartEl = modalEl.querySelector(".modal-chart");
const modalChartWrap = modalEl.querySelector(".modal-chart-wrap");
const modalTooltip = modalEl.querySelector(".modal-tooltip");
const modalAxis = modalEl.querySelector(".modal-axis");
const modalStatus = modalEl.querySelector(".modal-status");
const rangeBtns = modalEl.querySelectorAll(".range-btn");

let chartSymbol = null;
let chartCurrency = "";
let chartPoints = [];      // 描画した点の座標 {x, y, value, ts}
let chartReqId = 0;        // 古いリクエストの結果を無視するための番号

function openChart(symbol) {
  chartSymbol = symbol;
  modalEl.hidden = false;
  modalNameEl.textContent = symbol;
  modalSymbolEl.textContent = symbol;
  modalPriceEl.textContent = "—";
  modalChangeEl.className = "modal-change flat";
  modalChangeEl.innerHTML = "&nbsp;";
  // 既定の期間（1ヶ月）を選択した状態にする
  rangeBtns.forEach((b) => b.classList.toggle("active", b.dataset.range === "1mo"));
  // 最初の読み込みで上部の「前日比」も確定させる（以後は期間を変えても固定）
  loadChart("1mo", "1d", true);
}

function closeChart() {
  modalEl.hidden = true;
  chartSymbol = null;
  modalTooltip.hidden = true;
}

async function loadChart(range, interval, updateHeadline) {
  const symbol = chartSymbol;
  const reqId = ++chartReqId;
  modalChartEl.innerHTML = "";
  modalAxis.innerHTML = "";
  modalTooltip.hidden = true;
  chartPoints = [];
  modalStatus.textContent = "読み込み中…";
  try {
    const res = await fetch(
      `/api/quote?symbol=${encodeURIComponent(symbol)}&range=${range}&interval=${interval}`
    );
    const data = await res.json();
    if (reqId !== chartReqId) return; // 新しい操作が入ったので破棄
    if (data.error) {
      modalStatus.textContent = "⚠ " + data.error;
      return;
    }
    modalStatus.textContent = "";
    modalNameEl.textContent = data.name || symbol;
    modalSymbolEl.textContent = data.symbol;
    chartCurrency = data.currency;
    // 上部の価格と「前日比」は最初の読み込み時だけ確定（期間を変えても変わらない）
    if (updateHeadline) {
      modalPriceEl.textContent = fmtPrice(data.price, data.currency);
      if (data.change == null) {
        modalChangeEl.className = "modal-change flat";
        modalChangeEl.innerHTML = "&nbsp;";
      } else {
        const up = data.change >= 0;
        modalChangeEl.className = "modal-change " + (data.change === 0 ? "flat" : up ? "up" : "down");
        const sign = up ? "+" : "";
        modalChangeEl.textContent = `前日比 ${up ? "▲" : "▼"} ${sign}${data.change.toFixed(2)} (${sign}${data.changePct.toFixed(2)}%)`;
      }
    }
    drawBigChart(data.closes, data.timestamps);
  } catch {
    if (reqId !== chartReqId) return;
    modalStatus.textContent = "⚠ サーバーに接続できません";
  }
}

function drawBigChart(closes, timestamps) {
  const svg = modalChartEl;
  svg.innerHTML = "";
  modalAxis.innerHTML = "";
  chartPoints = [];
  if (!closes || closes.length < 2) {
    modalStatus.textContent = "この期間のデータがありません";
    return;
  }
  const W = 640, H = 300, padX = 4, padTop = 10, padBottom = 10;
  const min = Math.min(...closes);
  const max = Math.max(...closes);
  const span = max - min || 1;
  const stepX = (W - padX * 2) / (closes.length - 1);
  const yOf = (v) => padTop + (H - padTop - padBottom) * (1 - (v - min) / span);
  const coords = closes.map((c, i) => {
    const x = padX + i * stepX;
    return { x, y: yOf(c), value: c, ts: timestamps[i] };
  });
  chartPoints = coords;
  const ptStr = coords.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  // 線の色は、表示している期間の始点→終点で上がったか下がったかで決める
  const trend = closes[closes.length - 1] - closes[0];
  const color = trend >= 0 ? "var(--up)" : "var(--down)";

  // 横方向の目盛り線 + 右側の価格ラベル（高値〜安値を5段階で表示）
  const LEVELS = 5;
  for (let i = 0; i < LEVELS; i++) {
    const v = max - (span * i) / (LEVELS - 1);
    const y = yOf(v);
    const grid = document.createElementNS("http://www.w3.org/2000/svg", "line");
    grid.setAttribute("x1", padX);
    grid.setAttribute("x2", W - padX);
    grid.setAttribute("y1", y);
    grid.setAttribute("y2", y);
    grid.setAttribute("stroke", "var(--border)");
    grid.setAttribute("stroke-width", "1");
    grid.setAttribute("opacity", "0.5");
    svg.appendChild(grid);

    const label = document.createElement("div");
    label.className = "axis-label";
    label.textContent = fmtPrice(v, chartCurrency);
    label.style.top = (y / H) * 100 + "%";
    modalAxis.appendChild(label);
  }

  const area = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
  area.setAttribute("points", `${padX},${H} ${ptStr} ${W - padX},${H}`);
  area.setAttribute("fill", color);
  area.setAttribute("opacity", "0.12");
  svg.appendChild(area);

  const line = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
  line.setAttribute("points", ptStr);
  line.setAttribute("fill", "none");
  line.setAttribute("stroke", color);
  line.setAttribute("stroke-width", "2");
  line.setAttribute("stroke-linejoin", "round");
  line.setAttribute("stroke-linecap", "round");
  svg.appendChild(line);

  // ホバー用の縦線と点
  const cross = document.createElementNS("http://www.w3.org/2000/svg", "line");
  cross.setAttribute("class", "chart-cross");
  cross.setAttribute("y1", "0");
  cross.setAttribute("y2", H);
  cross.setAttribute("stroke", "var(--muted)");
  cross.setAttribute("stroke-width", "1");
  cross.setAttribute("stroke-dasharray", "4 4");
  cross.setAttribute("opacity", "0");
  svg.appendChild(cross);

  const dot = document.createElementNS("http://www.w3.org/2000/svg", "circle");
  dot.setAttribute("class", "chart-dot");
  dot.setAttribute("r", "4");
  dot.setAttribute("fill", color);
  dot.setAttribute("opacity", "0");
  svg.appendChild(dot);

  svg._cross = cross;
  svg._dot = dot;
}

function fmtChartDate(ts) {
  if (!ts) return "";
  const d = new Date(ts * 1000);
  const mo = d.getMonth() + 1;
  const day = d.getDate();
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  // 当日内（時刻が0:00以外）は時刻も表示
  if (hh !== "00" || mm !== "00") return `${mo}/${day} ${hh}:${mm}`;
  return `${d.getFullYear()}/${mo}/${day}`;
}

function handleChartHover(e) {
  if (!chartPoints.length) return;
  const svgRect = modalChartEl.getBoundingClientRect();
  const relX = (e.clientX - svgRect.left) / svgRect.width;
  let idx = Math.round(relX * (chartPoints.length - 1));
  idx = Math.max(0, Math.min(chartPoints.length - 1, idx));
  const p = chartPoints[idx];
  const svg = modalChartEl;
  if (svg._cross) {
    svg._cross.setAttribute("x1", p.x);
    svg._cross.setAttribute("x2", p.x);
    svg._cross.setAttribute("opacity", "1");
  }
  if (svg._dot) {
    svg._dot.setAttribute("cx", p.x);
    svg._dot.setAttribute("cy", p.y);
    svg._dot.setAttribute("opacity", "1");
  }
  modalTooltip.hidden = false;
  modalTooltip.innerHTML =
    `<div class="tt-price">${fmtPrice(p.value, chartCurrency)}</div>` +
    `<div class="tt-date">${fmtChartDate(p.ts)}</div>`;
  // ツールチップ位置（点のピクセル位置に合わせ、両端でずれないようclamp）
  const pxX = (p.x / 640) * svgRect.width;
  const wrapW = modalChartWrap.getBoundingClientRect().width;
  modalTooltip.style.left = Math.max(40, Math.min(wrapW - 40, pxX)) + "px";
}

function hideChartHover() {
  modalTooltip.hidden = true;
  const svg = modalChartEl;
  if (svg._cross) svg._cross.setAttribute("opacity", "0");
  if (svg._dot) svg._dot.setAttribute("opacity", "0");
}

rangeBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    rangeBtns.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    loadChart(btn.dataset.range, btn.dataset.interval, false);
  });
});

modalEl.querySelector(".modal-close").addEventListener("click", closeChart);
modalEl.querySelector(".modal-backdrop").addEventListener("click", closeChart);
modalChartWrap.addEventListener("mousemove", handleChartHover);
modalChartWrap.addEventListener("mouseleave", hideChartHover);
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !modalEl.hidden) closeChart();
});

/* ===== タブ切り替え ===== */

let currentView = "watchlist";

function switchView(view) {
  currentView = view;
  document.querySelectorAll(".tab").forEach((t) => {
    t.classList.toggle("active", t.dataset.view === view);
  });
  document.getElementById("view-watchlist").hidden = view !== "watchlist";
  document.getElementById("view-sectors-us").hidden = view !== "sectors-us";
  document.getElementById("view-sectors-jp").hidden = view !== "sectors-jp";
  document.getElementById("view-heatmap").hidden = view !== "heatmap";
  document.getElementById("view-news").hidden = view !== "news";
  if (view === "heatmap" && !heatmapBuilt) buildHeatmap();
  if (view === "news" && !newsLoaded) loadNews(newsRegion);
  if (view === "sectors-us" && !usSectorsSorted) { usSectorsSorted = true; sortSectorsByPerformance(usSectorListEl, SECTORS); }
  if (view === "sectors-jp" && !jpSectorsSorted) { jpSectorsSorted = true; sortSectorsByPerformance(jpSectorListEl, JP_SECTORS); }
}

document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => switchView(tab.dataset.view));
});

buildSectorGroup(SECTORS, usSectorListEl);
buildSectorGroup(JP_SECTORS, jpSectorListEl);
renderAll();
refreshAll();
refreshIndexStrip();

/* ===== 自動リフレッシュ（5分ごと） ===== */
const lastUpdatedEl = document.getElementById("lastUpdated");

function markUpdated() {
  const now = new Date();
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  lastUpdatedEl.textContent = `最終更新 ${hh}:${mm}`;
}

refreshBtn.addEventListener("click", markUpdated);
markUpdated();

setInterval(() => {
  quoteCache.clear();
  quoteFetching.clear();
  newsLoaded = false;
  usSectorsSorted = false;
  jpSectorsSorted = false;
  handleRefresh();
  refreshIndexStrip();
  markUpdated();
}, 5 * 60 * 1000);

/* ===== ニュース ===== */

function timeAgo(epochSec) {
  const diff = Math.floor(Date.now() / 1000) - epochSec;
  if (diff < 60) return "たった今";
  if (diff < 3600) return `${Math.floor(diff / 60)}分前`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}時間前`;
  return `${Math.floor(diff / 86400)}日前`;
}

function makeNewsCard(item) {
  const card = document.createElement("a");
  card.className = "news-card";
  card.href = item.link || "#";
  card.target = "_blank";
  card.rel = "noopener noreferrer";
  card.addEventListener("click", (e) => {
    if (item.link) { e.preventDefault(); window.open(item.link, "_blank"); }
  });
  const meta = `<span class="news-pub">${item.publisher || ""}</span>` +
    (item.time ? ` · ${timeAgo(item.time)}` : "");
  card.innerHTML =
    `<div class="news-body">` +
      `<div class="news-title">${item.title || "(タイトルなし)"}</div>` +
      `<div class="news-meta">${meta}</div>` +
    `</div>` +
    (item.thumb ? `<img class="news-thumb" src="${item.thumb}" alt="" loading="lazy">` : "");
  return card;
}

async function loadNews(region) {
  newsLoaded = true;
  newsPage[region] = 0;
  newsSeen[region] = new Set();
  newsListEl.innerHTML = Array(6).fill('<div class="news-skeleton"></div>').join("");
  try {
    const res = await fetch(`/api/news?region=${encodeURIComponent(region)}&page=0`);
    const data = await res.json();
    newsListEl.innerHTML = "";
    if (!data.items || !data.items.length) {
      newsListEl.innerHTML = '<div class="news-empty">ニュースを取得できませんでした</div>';
      return;
    }
    for (const item of data.items) {
      const key = item.uuid || item.title;
      newsSeen[region].add(key);
      newsListEl.appendChild(makeNewsCard(item));
    }
    appendLoadMoreBtn(region);
  } catch {
    newsListEl.innerHTML = '<div class="news-empty">サーバーに接続できません</div>';
  }
}

async function loadMoreNews(region) {
  if (newsLoadingMore) return;
  newsLoadingMore = true;
  const btn = newsListEl.querySelector(".news-load-more");
  if (btn) { btn.textContent = "読み込み中…"; btn.disabled = true; }
  newsPage[region]++;
  try {
    const res = await fetch(`/api/news?region=${encodeURIComponent(region)}&page=${newsPage[region]}`);
    const data = await res.json();
    if (btn) btn.remove();
    let added = 0;
    for (const item of (data.items || [])) {
      const key = item.uuid || item.title;
      if (!newsSeen[region].has(key)) {
        newsSeen[region].add(key);
        newsListEl.appendChild(makeNewsCard(item));
        added++;
      }
    }
    if (added > 0) appendLoadMoreBtn(region);
  } catch {
    if (btn) { btn.textContent = "⟳ もっと見る"; btn.disabled = false; }
  } finally {
    newsLoadingMore = false;
  }
}

function appendLoadMoreBtn(region) {
  const btn = document.createElement("button");
  btn.className = "news-load-more ghost";
  btn.textContent = "⟳ もっと見る";
  btn.addEventListener("click", () => loadMoreNews(region));
  newsListEl.appendChild(btn);
}

document.querySelectorAll(".news-region-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".news-region-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    newsRegion = btn.dataset.region;
    loadNews(newsRegion);
  });
});
