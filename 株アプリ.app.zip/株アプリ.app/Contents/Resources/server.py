#!/usr/bin/env python3
"""株ウォッチリスト用のかんたんローカルサーバー。
追加インストール不要（Python標準ライブラリのみ）。
使い方:  python3 server.py  → ブラウザで http://localhost:8800 を開く
"""
import json
import os
import re
import socket
import urllib.request
import urllib.error
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

PORT = 8800
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
YAHOO = "https://query1.finance.yahoo.com/v8/finance/chart/"
TRENDING = "https://query1.finance.yahoo.com/v1/finance/trending/"
NEWS_SEARCH = "https://query1.finance.yahoo.com/v1/finance/search"


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def log_message(self, *args):
        pass  # ログを静かに

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/quote":
            self.handle_quote(parse_qs(parsed.query))
            return
        if parsed.path == "/api/trending":
            self.handle_trending(parse_qs(parsed.query))
            return
        if parsed.path == "/api/news":
            self.handle_news(parse_qs(parsed.query))
            return
        super().do_GET()

    def handle_trending(self, query):
        # 今注目されている銘柄（Yahoo Finance のトレンド）を返す。毎回ライブ取得＝毎日自動で入れ替わる。
        region = re.sub(r"[^A-Za-z]", "", (query.get("region") or ["US"])[0]) or "US"
        try:
            count = max(1, min(30, int((query.get("count") or ["20"])[0])))
        except ValueError:
            count = 20
        url = f"{TRENDING}{region}?count={count}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            results = data.get("finance", {}).get("result", []) or []
            quotes = results[0].get("quotes", []) if results else []
            symbols = [q.get("symbol") for q in quotes if q.get("symbol")]
            self.send_json({"region": region, "symbols": symbols})
        except Exception:
            # 取得できなくてもアプリは止めない（空で返す）
            self.send_json({"region": region, "symbols": []})

    def translate_ja(self, texts):
        """Google Translate 無料エンドポイントで日本語に翻訳（改行区切りバッチ）。"""
        if not texts:
            return texts
        joined = "\n".join(texts)
        url = (
            "https://translate.googleapis.com/translate_a/single"
            "?client=gtx&sl=auto&tl=ja&dt=t&q=" + urllib.parse.quote(joined)
        )
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            translated = "".join(s[0] for s in data[0] if s and s[0])
            parts = [p.strip() for p in translated.split("\n") if p.strip()]
            if len(parts) == len(texts):
                return parts
            # 件数がずれた場合は合わせる（残りは原文のまま）
            out = list(texts)
            for i, p in enumerate(parts):
                if i < len(out):
                    out[i] = p
            return out
        except Exception:
            return texts  # 翻訳失敗時は原文を返す

    def fetch_news_for_query(self, q, count=20):
        """Yahoo Finance search API からニュースを取得して正規化リストを返す。"""
        url = (
            f"{NEWS_SEARCH}?q={urllib.parse.quote(q)}"
            f"&newsCount={count}&lang=en-US&region=US"
            f"&enableFuzzyQuery=false&enableCb=false&enableNavLinks=false"
        )
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        items = []
        for n in data.get("news", []) or []:
            thumb = ""
            if n.get("thumbnail"):
                resols = n["thumbnail"].get("resolutions", []) or []
                if resols:
                    thumb = min(resols, key=lambda r: r.get("width", 9999)).get("url", "")
            items.append({
                "uuid": n.get("uuid", ""),
                "title": n.get("title", ""),
                "publisher": n.get("publisher", ""),
                "link": n.get("link", ""),
                "time": n.get("providerPublishTime", 0),
                "thumb": thumb,
            })
        return items

    # ページごとに銘柄・テーマを変えて多様な記事を取得（各ページ複数クエリを集約）
    US_NEWS_PAGES = [
        ["stock market S&P 500 NASDAQ"],           # p0: 全般
        ["AAPL", "MSFT", "NVDA"],                  # p1: 大型テック
        ["TSLA", "AMZN", "META"],                  # p2: 消費者テック
        ["JPM", "GS", "BAC"],                      # p3: 金融
        ["XOM", "CVX", "oil energy"],              # p4: エネルギー
        ["MRNA", "PFE", "JNJ"],                    # p5: ヘルスケア
        ["BTC-USD", "COIN", "ETH-USD"],            # p6: 仮想通貨
        ["INTC", "AMD", "ASML"],                   # p7: 半導体
        ["AMZN", "SHOP", "WMT"],                   # p8: 小売
        ["Federal Reserve inflation interest rates"], # p9: マクロ
    ]
    JP_NEWS_QUERIES = [
        ["^N225"],
        ["7203.T", "9984.T", "6758.T"],
        ["8035.T", "6861.T", "8306.T"],
        ["7974.T", "4502.T", "8058.T"],
        ["^N225"],   # 5ページ以降は先頭に戻る
    ]

    def handle_news(self, query):
        region = re.sub(r"[^A-Za-z]", "", (query.get("region") or ["US"])[0]) or "US"
        try:
            page = max(0, min(20, int((query.get("page") or ["0"])[0])))
        except (ValueError, TypeError):
            page = 0
        try:
            if region == "JP":
                queries = self.JP_NEWS_QUERIES[page % len(self.JP_NEWS_QUERIES)]
                seen, items = set(), []
                for q in queries:
                    try:
                        for item in self.fetch_news_for_query(q, count=10):
                            uid = item["uuid"] or item["title"]
                            if uid not in seen:
                                seen.add(uid)
                                items.append(item)
                    except Exception:
                        pass
                items.sort(key=lambda x: x["time"], reverse=True)
                items = items[:20]
            else:
                queries = self.US_NEWS_PAGES[page % len(self.US_NEWS_PAGES)]
                seen, items = set(), []
                for q in queries:
                    try:
                        for item in self.fetch_news_for_query(q, count=10):
                            uid = item["uuid"] or item["title"]
                            if uid not in seen:
                                seen.add(uid)
                                items.append(item)
                    except Exception:
                        pass
                items.sort(key=lambda x: x["time"], reverse=True)
                items = items[:20]

            # タイトルを日本語に翻訳
            titles = [item["title"] for item in items]
            translated = self.translate_ja(titles)
            for item, t in zip(items, translated):
                item["title"] = t
            self.send_json({"region": region, "items": items, "page": page})
        except Exception as e:
            self.send_json({"region": region, "items": [], "error": str(e)})

    def handle_quote(self, query):
        symbol = (query.get("symbol") or [""])[0].strip()
        rng = (query.get("range") or ["1mo"])[0]
        interval = (query.get("interval") or ["1d"])[0]
        if not symbol:
            self.send_json({"error": "symbol is required"}, 400)
            return
        url = f"{YAHOO}{urllib.parse.quote(symbol)}?range={rng}&interval={interval}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            self.send_json(self.simplify(symbol, data, interval))
        except urllib.error.HTTPError as e:
            self.send_json({"error": f"取得失敗 ({e.code}) 銘柄コードを確認してください"}, 502)
        except Exception as e:
            self.send_json({"error": f"通信エラー: {e}"}, 502)

    def simplify(self, symbol, data, interval="1d"):
        try:
            result = data["chart"]["result"][0]
            meta = result["meta"]
            timestamps = result.get("timestamp", []) or []
            closes = (result.get("indicators", {}).get("quote", [{}])[0].get("close", [])) or []
            points = [c for c in closes if c is not None]
            price = meta.get("regularMarketPrice")
            prev = meta.get("chartPreviousClose") or meta.get("previousClose")
            # 「前日比（今日の変化）」を出す。日足データなら直前の営業日の終値を基準にする。
            if interval == "1d" and len(points) >= 2:
                prev = points[-2]
            change = None
            change_pct = None
            if price is not None and prev:
                change = price - prev
                change_pct = change / prev * 100
            return {
                "symbol": symbol,
                "name": meta.get("longName") or meta.get("shortName") or symbol,
                "type": meta.get("instrumentType"),
                "currency": meta.get("currency", ""),
                "price": price,
                "previousClose": prev,
                "change": change,
                "changePct": change_pct,
                "timestamps": timestamps,
                "closes": points,
            }
        except (KeyError, IndexError, TypeError):
            return {"error": "データ形式が想定外でした", "symbol": symbol}

    def send_json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        local_ip = "127.0.0.1"
    host_name = socket.gethostname().replace(".local", "")
    print(f"株ウォッチリストを起動しました")
    print(f"  PC:           http://localhost:{PORT}")
    print(f"  スマホ(固定): http://{host_name}.local:{PORT}  ← おすすめ・変わらない")
    print(f"  スマホ(IP):   http://{local_ip}:{PORT}  ← 同じWi-Fiで開く")
    print("止めるには Ctrl+C を押してください")
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
